<?php
//var_dump($_POST);
require '../config.php';
require_once '../functions.php';
//if(isset($_POST))
//{
    $fname=clearInputs($_POST['fname']);
    $lname=clearInputs($_POST['lname']);
    $password=sha1(clearInputs($_POST['password']));
    $email=clearInputs($_POST['email']);
    $job=clearInputs($_POST['job']);
    $birthday=clearInputs($_POST['birthday']);
    $credit_limit=clearInputs($_POST['credit_limit']);
    $address=clearInputs($_POST['address']);

//}
$user=new User();

$user->id=NULL;
$user->fname=$fname;
$user->lname=$lname;
$user->password=$password;
$user->birthday=$birthday;
$user->email=$email;
$user->job=$job;
$user->credit_limit=$credit_limit;
$user->address=$address;
$user->created_at=date();
var_dump($user);
//if($user->insert())
//    echo 'Inserted';
//else
//    echo 'Error';